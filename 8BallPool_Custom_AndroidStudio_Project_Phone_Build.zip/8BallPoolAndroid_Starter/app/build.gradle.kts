plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.anik.eightballpool"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.anik.eightballpool"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "0.2"
    }
}
