package com.anik.eightballpool

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.content.res.ColorStateList
import android.view.*
import android.widget.*
import android.content.Context
import kotlin.math.*

class MainActivity : Activity() {
    private val navy = Color.rgb(9, 17, 33)
    private val panel = Color.rgb(19, 31, 50)
    private val gold = Color.rgb(246, 190, 72)
    private val cream = Color.rgb(248, 245, 235)
    private lateinit var stage: FrameLayout
    private lateinit var pool: PoolView
    private lateinit var menuPanel: LinearLayout
    private lateinit var stats: TextView
    private var menuOpen = false
    private var coins = 1_000_000_000_000L
    private var cash = 1_000_000_000_000L
    private var diamonds = 1_000_000_000_000L
    private var level = 999
    private var aimLock = false
    private var longLines = true
    private var cueControl = true
    private var autoPlay = false
    private var premiumPass = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun button(label: String, onTap: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 13f
            isAllCaps = false
            setTextColor(Color.rgb(15, 24, 38))
            backgroundTintList = ColorStateList.valueOf(gold)
            setOnClickListener { onTap() }
        }

    private fun text(label: String, size: Float = 16f, color: Int = cream) =
        TextView(this).apply {
            text = label
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            setPadding(5, 6, 5, 6)
        }

    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setPadding(22, 24, 22, 24)
        setBackgroundColor(navy)
    }

    private fun showHome() {
        val root = base()
        root.addView(text("🎱", 66f))
        root.addView(text("8 BALL POOL", 30f))
        root.addView(text("CUSTOM PRACTICE EDITION", 13f, gold))
        root.addView(text("Offline billiards prototype with a customizable control menu.", 14f, Color.LTGRAY))
        root.addView(button("PLAY NOW") { showGame() }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 24; bottomMargin = 10 })
        root.addView(button("PLAYER LOGIN") { showAuth(false) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })
        root.addView(button("CREATE ACCOUNT") { showAuth(true) })
        root.addView(text("Prototype: login UI only; no account service connected.", 11f, Color.GRAY))
        setContentView(root)
    }

    private fun showAuth(register: Boolean) {
        val root = base()
        root.addView(text(if (register) "CREATE ACCOUNT" else "PLAYER LOGIN", 25f))
        val name = EditText(this).apply { hint = "Player name / email"; setSingleLine(); setTextColor(cream); setHintTextColor(Color.GRAY) }
        val pass = EditText(this).apply { hint = "Password"; inputType = 129; setSingleLine(); setTextColor(cream); setHintTextColor(Color.GRAY) }
        root.addView(name, LinearLayout.LayoutParams(-1, 54))
        root.addView(pass, LinearLayout.LayoutParams(-1, 54))
        if (register) {
            val confirm = EditText(this).apply { hint = "Confirm password"; inputType = 129; setSingleLine(); setTextColor(cream); setHintTextColor(Color.GRAY) }
            root.addView(confirm, LinearLayout.LayoutParams(-1, 54))
        }
        root.addView(button(if (register) "REGISTER (DEMO)" else "LOGIN (DEMO)") {
            Toast.makeText(this, "Demo UI only. Connect a secure authentication backend for real accounts.", Toast.LENGTH_LONG).show()
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 16 })
        root.addView(button("BACK") { showHome() }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
        setContentView(root)
    }

    private fun showGame() {
        stage = FrameLayout(this).apply { setBackgroundColor(navy) }
        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(navy) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(8, 5, 8, 5) }
        bar.addView(button("‹ Home") { showHome() }, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(text("8 BALL POOL", 18f), LinearLayout.LayoutParams(0, -2, 2f))
        bar.addView(button("RESET") { pool.resetGame() }, LinearLayout.LayoutParams(0, -2, 1f))
        column.addView(bar)
        stats = text(statsLine(), 11f, gold)
        column.addView(stats)
        pool = PoolView(this)
        column.addView(pool, LinearLayout.LayoutParams(-1, 0, 1f))
        column.addView(text("Drag away from the cue ball and release to shoot", 12f, Color.LTGRAY))
        stage.addView(column, FrameLayout.LayoutParams(-1, -1))

        val menuButton = TextView(this).apply {
            text = "☰"
            textSize = 26f
            gravity = Gravity.CENTER
            setTextColor(Color.BLACK)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(gold); setStroke(3, Color.WHITE) }
            elevation = 12f
            setOnClickListener { menuOpen = !menuOpen; menuPanel.visibility = if (menuOpen) View.VISIBLE else View.GONE }
        }
        val menuSize = (resources.displayMetrics.density * 58).toInt()
        stage.addView(menuButton, FrameLayout.LayoutParams(menuSize, menuSize, Gravity.END or Gravity.TOP).apply {
            topMargin = (resources.displayMetrics.density * 72).toInt()
            rightMargin = (resources.displayMetrics.density * 12).toInt()
        })

        menuPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 10, 12, 10)
            background = GradientDrawable().apply {
                setColor(Color.argb(245, 13, 23, 39))
                cornerRadius = 22f
                setStroke(2, gold)
            }
            elevation = 18f
            visibility = View.GONE
        }
        val scroll = ScrollView(this)
        val controls = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        controls.addView(text("🎮 CUSTOM CONTROL MENU", 17f, gold))
        controls.addView(text("Practice sandbox settings", 11f, Color.LTGRAY))
        controls.addView(currencyControl("COINS", { coins }, { coins = it }))
        controls.addView(currencyControl("CASH / CUES", { cash }, { cash = it }))
        controls.addView(currencyControl("DIAMONDS", { diamonds }, { diamonds = it }))
        controls.addView(stepper("LEVEL", { level }, { level = it.coerceIn(1, 9999) }))
        controls.addView(toggleRow("Aim Lock", { aimLock }, { aimLock = it; pool.aimLock = it }))
        controls.addView(toggleRow("Long Aim Lines", { longLines }, { longLines = it; pool.longLines = it }))
        controls.addView(toggleRow("Cue Ball Control", { cueControl }, { cueControl = it }))
        controls.addView(toggleRow("Auto Play (demo)", { autoPlay }, { autoPlay = it }))
        controls.addView(toggleRow("Premium Pass (local demo)", { premiumPass }, { premiumPass = it }))
        controls.addView(button("RESET TABLE") { pool.resetGame() })
        controls.addView(button("CLOSE MENU") { menuOpen = false; menuPanel.visibility = View.GONE })
        scroll.addView(controls)
        menuPanel.addView(scroll)
        val width = (resources.displayMetrics.widthPixels * .82f).toInt().coerceAtMost(620)
        stage.addView(menuPanel, FrameLayout.LayoutParams(width, (resources.displayMetrics.heightPixels * .69f).toInt(), Gravity.END or Gravity.CENTER_VERTICAL).apply {
            rightMargin = (resources.displayMetrics.density * 12).toInt()
        })
        setContentView(stage)
        refreshStats()
    }

    private fun statsLine() = "Level $level   •   Coins $coins   •   Cash $cash   •   Diamonds $diamonds"

    private fun refreshStats() { if (::stats.isInitialized) stats.text = statsLine() }

    private fun currencyControl(label: String, get: () -> Long, set: (Long) -> Unit): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 4, 0, 4) }
        box.addView(text("$label: ${get()}", 12f))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(button("− 1M") { set((get() - 1_000_000L).coerceAtLeast(0)); box.getChildAt(0).let { (it as TextView).text = "$label: ${get()}" }; refreshStats() }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(button("+ 1M") { set((get() + 1_000_000L).coerceAtMost(9_000_000_000_000_000L)); box.getChildAt(0).let { (it as TextView).text = "$label: ${get()}" }; refreshStats() }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(button("MAX") { set(1_000_000_000_000L); box.getChildAt(0).let { (it as TextView).text = "$label: ${get()}" }; refreshStats() }, LinearLayout.LayoutParams(0, -2, 1f))
        box.addView(row)
        return box
    }

    private fun stepper(label: String, get: () -> Int, set: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val value = text("$label: ${get()}", 13f)
        row.addView(value, LinearLayout.LayoutParams(0, -2, 1.4f))
        row.addView(button("−") { set(get() - 1); value.text = "$label: ${get()}"; refreshStats() }, LinearLayout.LayoutParams(0, -2, .6f))
        row.addView(button("+") { set(get() + 1); value.text = "$label: ${get()}"; refreshStats() }, LinearLayout.LayoutParams(0, -2, .6f))
        return row
    }

    private fun toggleRow(label: String, get: () -> Boolean, set: (Boolean) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(3, 3, 3, 3) }
        row.addView(text(label, 13f, cream), LinearLayout.LayoutParams(0, -2, 1f))
        val toggle = Switch(this).apply {
            isChecked = get()
            text = if (isChecked) "ON" else "OFF"
            setTextColor(gold)
            setOnCheckedChangeListener { _, checked -> text = if (checked) "ON" else "OFF"; set(checked) }
        }
        row.addView(toggle)
        return row
    }
}

private class PoolView(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val balls = mutableListOf<Ball>()
    var aimLock = false
    var longLines = true
    private var aiming = false
    private var aimX = 0f
    private var aimY = 0f
    private var radius = 14f
    private var inner = RectF()
    private var last = System.nanoTime()
    private val colors = intArrayOf(Color.YELLOW, Color.BLUE, Color.RED, 0xff7d35aa.toInt(), 0xffff7a18.toInt(), Color.GREEN, 0xff9b2020.toInt(), Color.BLACK)

    fun resetGame() { balls.clear(); invalidate() }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat(); val h = height.toFloat()
        if (w < 1 || h < 1) return
        val outer = RectF(w*.045f, h*.05f, w*.955f, h*.95f)
        p.color = 0xff5a321d.toInt(); c.drawRoundRect(outer, 26f, 26f, p)
        inner = RectF(outer.left+18, outer.top+18, outer.right-18, outer.bottom-18)
        p.color = 0xff08734b.toInt(); c.drawRoundRect(inner, 12f, 12f, p)
        p.color = 0xff041d17.toInt()
        val pocketR = min(w,h)*.035f
        val pockets = pocketPoints()
        pockets.forEach { c.drawCircle(it.first, it.second, pocketR, p) }
        radius = min(w,h)*.024f
        if (balls.isEmpty()) arrangeBalls()
        val cue = balls.firstOrNull { it.cue && !it.pocketed }
        if (aiming && cue != null) {
            p.color = if (aimLock) 0xfff6be48.toInt() else Color.WHITE
            p.strokeWidth = if (aimLock) 5f else 2.5f
            val length = if (longLines) 2f else .75f
            c.drawLine(cue.x, cue.y, cue.x+(cue.x-aimX)*length, cue.y+(cue.y-aimY)*length, p)
        }
        balls.forEach { b ->
            if (b.pocketed) return@forEach
            p.color = 0x70000000; c.drawCircle(b.x+3, b.y+4, radius, p)
            p.color = if (b.cue) Color.WHITE else colors[(b.number-1).coerceIn(0, colors.lastIndex)]
            c.drawCircle(b.x,b.y,radius,p)
            if (!b.cue) {
                p.color = Color.WHITE; c.drawCircle(b.x,b.y,radius*.48f,p)
                p.color = Color.BLACK; p.textSize = radius*.7f; p.textAlign = Paint.Align.CENTER
                c.drawText(b.number.toString(),b.x,b.y+radius*.24f,p)
            }
        }
        physics()
        postInvalidateOnAnimation()
    }

    private fun arrangeBalls() {
        val cx = inner.centerX()+inner.width()*.18f
        val cy = inner.centerY()
        var n=1
        for (r in 0..4) for (col in 0..r) {
            if (n>15) continue
            balls.add(Ball(cx+r*radius*1.8f, cy+(col-r/2f)*radius*2f,n,false)); n++
        }
        balls.add(0, Ball(inner.left+inner.width()*.24f, inner.centerY(),0,true))
    }

    private fun pocketPoints() = listOf(inner.left to inner.top, inner.centerX() to inner.top, inner.right to inner.top,
        inner.left to inner.bottom, inner.centerX() to inner.bottom, inner.right to inner.bottom)

    private fun physics() {
        val now=System.nanoTime(); val dt=min((now-last)/1e9f,.03f); last=now
        balls.forEach { b ->
            if (b.pocketed) return@forEach
            b.x+=b.vx*dt; b.y+=b.vy*dt
            val friction=exp(-1.2f*dt); b.vx*=friction; b.vy*=friction
            if (abs(b.vx)<5) b.vx=0f
            if (abs(b.vy)<5) b.vy=0f
            if (b.x<inner.left+radius || b.x>inner.right-radius) { b.vx *= -.82f; b.x=b.x.coerceIn(inner.left+radius,inner.right-radius) }
            if (b.y<inner.top+radius || b.y>inner.bottom-radius) { b.vy *= -.82f; b.y=b.y.coerceIn(inner.top+radius,inner.bottom-radius) }
        }
        for (i in balls.indices) for (j in i+1 until balls.size) {
            val a=balls[i]; val b=balls[j]; if(a.pocketed||b.pocketed) continue
            val dx=b.x-a.x; val dy=b.y-a.y; val d=hypot(dx,dy)
            if(d>0 && d<radius*2) {
                val nx=dx/d; val ny=dy/d; val overlap=radius*2-d
                a.x-=nx*overlap/2; a.y-=ny*overlap/2; b.x+=nx*overlap/2; b.y+=ny*overlap/2
                val rel=(a.vx-b.vx)*nx+(a.vy-b.vy)*ny
                if(rel>0) { a.vx-=rel*nx; a.vy-=rel*ny; b.vx+=rel*nx; b.vy+=rel*ny }
            }
        }
        balls.forEach { b -> if(!b.pocketed && pocketPoints().any { hypot(b.x-it.first,b.y-it.second)<min(width,height)*.035f }) {
            if(b.cue) { b.x=inner.left+inner.width()*.24f; b.y=inner.centerY(); b.vx=0f; b.vy=0f } else b.pocketed=true
        } }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val cue=balls.firstOrNull { it.cue && !it.pocketed } ?: return true
        when(e.action) {
            MotionEvent.ACTION_DOWN -> { aiming=true; aimX=e.x; aimY=e.y; invalidate(); return true }
            MotionEvent.ACTION_MOVE -> { aimX=e.x; aimY=e.y; invalidate(); return true }
            MotionEvent.ACTION_UP -> {
                val dx=cue.x-e.x; val dy=cue.y-e.y; val d=max(1f,hypot(dx,dy))
                val force=if(aimLock) min(420f,d*9f) else min(300f,d*7f)
                cue.vx=dx/d*force; cue.vy=dy/d*force
                aiming=false; invalidate(); return true
            }
        }
        return true
    }

    private data class Ball(var x:Float,var y:Float,val number:Int,val cue:Boolean,var vx:Float=0f,var vy:Float=0f,var pocketed:Boolean=false)
}
