# Eight Ball Pool-style Android starter

This is an independent offline prototype, not the official 8 Ball Pool game. It does not connect to Miniclip accounts or servers. Some menu options are demo/local toggles and it is not a finished online multiplayer game.

## Build APK using a phone and GitHub Actions
1. Sign in to GitHub in your phone browser and create a new repository.
2. Upload the contents of this project to the repository's `main` branch, including the hidden `.github/workflows/build-apk.yml` file. If your phone's ZIP uploader hides dot-folders, create the workflow file in GitHub at `.github/workflows/build-apk.yml` and paste the contents from this file.
3. Open the repository's **Actions** tab and select **Build Android APK**. If needed, tap **Run workflow**.
4. When the workflow finishes successfully, open that run and download the `pool-game-debug-apk` artifact.
5. Extract the downloaded artifact ZIP and tap `app-debug.apk` to install. Android may ask you to allow installs from that browser/file manager; only enable it for the app you trust, then turn it off again afterward.

The APK is a debug build. The project has not been built or tested in this environment, so the cloud build may reveal issues that need fixing.
